//递归实现斐波那契数列
#include <stdio.h>
int int_fun(int n)      //n代表第几项。特别指出：0是第0项，不是第1项。
{
    if (n <= 1)
        return n;
    else
        return int_fun(n-1) + int_fun(n-2);
}
long long_fun(int n)      //n代表第几项。特别指出：0是第0项，不是第1项。
{
    if (n <= 1)
        return (long)n;
    else
        return int_fun(n-1) + int_fun(n-2);
}
unsigned int uint_fun(int n)      //n代表第几项。特别指出：0是第0项，不是第1项。
{
    if (n <= 1)
        return (unsigned)n;
    else
        return int_fun(n-1) + int_fun(n-2);
}
unsigned long ulong_fun(int n)      //n代表第几项。特别指出：0是第0项，不是第1项。
{
    if (n <= 1)
        return (unsigned long)n;
    else
        return int_fun(n-1) + int_fun(n-2);
}
 
int main()
{
    int n=100;
    int i;
    for (i = 0; i < n+1; i++)         //输出所有项
    {
        printf("%d\t", int_fun(i));
    }
    return 0;
}