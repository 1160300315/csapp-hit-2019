#include <stdio.h>
#include <string.h>
int utf8len(char* s);
//字节x的第n位 1<<n<<8
int n_bit(unsigned char x,int n){
   // printf("%x的第%d位是%.2x\n",x,n,(x>>(n-1))&1);
    return (x>>(n-1))&1;
}
int main() {
    char* s = "江曦";
    printf("%d\n",utf8len(s));
    char* s1 = "一";
    char* s2 = "二";
    printf("%d",strcmp(s1,s2));
    return 0;
}
int utf8len(char* s){
    int len = strlen(s);
    //printf("%d\n",len);
    int utf8_len = 0;
    /*for(int i=0;i<len;i++){
        printf("%x\n",(unsigned char)s[i]);
    }*/
    for(int i=0;i<len;i++){
        if(n_bit((unsigned char)s[i],8)==0){
            utf8_len++;
            continue;
        }
        else {
            if(n_bit((unsigned char)s[i],7)==1){
                if(n_bit((unsigned char)s[i],6)==0){
                    utf8_len++;
                    continue;
                }
                else{
                    if(n_bit((unsigned char)s[i],5)==0){
                        utf8_len++;
                        continue;
                    }
                    else{
                        if(n_bit((unsigned char)s[i],4)==0){
                            utf8_len++;
                            continue;
                        }
                    }
                }
            }
        }
    }    
    return utf8_len;
}