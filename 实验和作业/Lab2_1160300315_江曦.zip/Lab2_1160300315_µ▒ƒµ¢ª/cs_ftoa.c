//浮点数转字符串
#include <stdio.h>
#include <math.h>
void cs_ftoa(float f,char s[]);
int main(){
    float a = 123.34;
    char s[100];
    cs_ftoa(a,s);
    printf("%s\n",s);

	float a1 = 10.7;
    char s1[100];
    cs_ftoa(a1,s1);
    printf("%s\n",s1);
    return 0;
}
void cs_ftoa(float f,char s[]){
	int int_f = (int)f;//浮点数的整数部分
	int f_int[100];
	int i = 0;
	for( i=0;i<100;i++){
        int b = int_f/pow(10,i);
        if(b!=0){
            f_int[i] = b%10;
        }
        else{
            break;
        }
    }
    int k=0;
    for(int j = i-1;j>=0;j--){
       s[k]=f_int[j]+48;
        k++;
    }
	int int_num = k-1;//整数位数 从0计数
	s[k] = '.';
	k++;
 
	float frac = f - (int)f;//小数部分提取
	for(i=int_num+2;i<10;i++){
        int b = frac*pow(10,i-int_num);
		//printf("b%d\t",b);
        if(b!=0){
            f_int[i] = b%10;
			//printf("%d\n",f_int[i]);
        }
        else{
            break;
        }
    }
	for(int j = int_num+2;j<i;j++){
       	s[k]=f_int[j]+48;
    	//printf("%c\n",s[k]);
        k++;
    }
	s[k] = '\0';

}