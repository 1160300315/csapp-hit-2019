//字符串转整数
#include <stdio.h>
#include <string.h>
#include <math.h>
int cs_atoi(char* s);
int main(){
    char *s = "1234";
    printf("%d\n",cs_atoi(s));
    return 0;
}
int cs_atoi(char* s){
    int len = strlen(s);
    int s_int[len];
    int final = 0;
    for(int i=0;i<len;i++){
        s_int[i] = (int)s[i]-48;
        //printf("%d\n",s_int[i]);
        final+=s_int[i]*pow(10,len-i-1);
    }
    return final;
}