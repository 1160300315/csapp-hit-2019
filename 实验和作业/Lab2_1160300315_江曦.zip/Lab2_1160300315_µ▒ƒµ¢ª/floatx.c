#include <stdio.h>
#include <float.h>
#include <limits.h>
int main(){
    //+0
    float pos_0 = 0;
    unsigned char *p1 = (char*)&pos_0;
    *p1=0x00;
    *(p1+1)=0x00;
    *(p1+2)=0x00;
    *(p1+3)=0x00;
    printf("+0:\n%.2x\t%.2x\t%.2x\t%.2x\n",*p1,*(p1+1),*(p1+2),*(p1+3));
    printf("%0.20e\n",pos_0);

    //-0
    float neg_0 = 0;
    unsigned char *p2 = (char*)&neg_0;
    *p2=0x00;
    *(p2+1)=0x00;
    *(p2+2)=0x00;
    *(p2+3)=0x80;
    printf("-0:\n%.2x\t%.2x\t%.2x\t%.2x\n",*p2,*(p2+1),*(p2+2),*(p2+3));
    printf("%0.20e\n",neg_0);

    //最小浮点正数
    float min_pos = 0;
    unsigned char *p3 = (char*)&min_pos;
    *p3=0x01;
    *(p3+1)=0x00;
    *(p3+2)=0x00;
    *(p3+3)=0x00;
    printf("最小浮点正数:\n%.2x\t%.2x\t%.2x\t%.2x\n",*p3,*(p3+1),*(p3+2),*(p3+3));
    printf("%0.20e\n",min_pos);

    //最大浮点正数
    float max_pos = 0;
    unsigned char *p4 = (char*)&max_pos;
    *p4=0xff;
    *(p4+1)=0xff;
    *(p4+2)=0x7f;
    *(p4+3)=0x7f;
    printf("最大浮点正数:\n%.2x\t%.2x\t%.2x\t%.2x\n",*p4,*(p4+1),*(p4+2),*(p4+3));
    printf("%0.20e\n",max_pos);
   
   //最小正的规格化正数
   float min_pos_norm = 0;
    unsigned char *p5 = (char*)&min_pos_norm;
    *p5=0x01;
    *(p5+1)=0x00;
    *(p5+2)=0x80;
    *(p5+3)=0x00;
    printf("最小正的规格化正数:\n%.2x\t%.2x\t%.2x\t%.2x\n",*p5,*(p5+1),*(p5+2),*(p5+3));
    printf("%0.20e\n",min_pos_norm);

   //正无穷大
   float pos_inf = 0;
    unsigned char *p6 = (char*)&pos_inf;
    *p6=0x00;
    *(p6+1)=0x00;
    *(p6+2)=0x80;
    *(p6+3)=0x7f;
    printf("正无穷大:\n%.2x\t%.2x\t%.2x\t%.2x\n",*p6,*(p6+1),*(p6+2),*(p6+3));
    printf("%0.20e\n",pos_inf);

   //NaN
   float nan = 0;
    unsigned char *p7 = (char*)&nan;
    *p7=0x01;
    *(p7+1)=0x00;
    *(p7+2)=0xf8;
    *(p7+3)=0x7f;
    printf("nan:\n%.2x\t%.2x\t%.2x\t%.2x\n",*p7,*(p7+1),*(p7+2),*(p7+3));
    printf("%0.20e\n",nan);
}
