//循环实现斐波那契数列
#include <stdio.h>
void int_fun(int n){
    int fun[n];
    for(int i=0;i<=n;i++){
        if(i==0||i==1){
            fun[i]=i;
        }
        else{
            fun[i]=fun[i-1]+fun[i-2];
        }
        printf("%d\t",fun[i]);
    }
    printf("\n");
}
void long_fun(int n){
    long fun[n];
    for(int i=0;i<=n;i++){
        if(i==0||i==1){
            fun[i]=(long)i;
        }
        else{
            fun[i]=fun[i-1]+fun[i-2];
        }
        printf("%ld\t",fun[i]);
    }
    printf("\n");
}
void uint_fun(int n){
    unsigned int fun[n];
    for(int i=0;i<=n;i++){
        if(i==0||i==1){
            fun[i]=(unsigned)i;
        }
        else{
            fun[i]=fun[i-1]+fun[i-2];
        }
        printf("%u\t",fun[i]);
    }
    printf("\n");
}
void ulong_fun(int n){
    unsigned long fun[n];
    for(int i=0;i<=n;i++){
        if(i==0||i==1){
            fun[i]=(unsigned long)i;
        }
        else{
            fun[i]=fun[i-1]+fun[i-2];
        }
        printf("%lu\t",fun[i]);
    }
    printf("\n");
}
int main(){
    int_fun(47);
    long_fun(93);
    uint_fun(48);
    ulong_fun(95);
    return 0;
}