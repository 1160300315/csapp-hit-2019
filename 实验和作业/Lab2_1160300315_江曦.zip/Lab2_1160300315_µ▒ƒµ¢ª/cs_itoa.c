//整数转字符串
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
void cs_itoa(int a,char s[]);
int main(){
    int a = 123;//要转换的整数值
    char s[100];
    cs_itoa(a,s);
    printf("%s\n",s);
    return 0;
}
void cs_itoa(int a,char s[]){
    int a_int[100];
    int i = 0;
    for(i=0;i<100;i++){
        int b = a/pow(10,i);
        //printf("b%d\n",b);
        //printf("i%d\n",i);
        if(b!=0){
            a_int[i] = b%10;
            //printf("%d\n",a_int[i]);
        }
        else{
            break;
        }
    }
    int k=0;
    for(int j = i-1;j>=0;j--){
       s[k]=a_int[j]+48;
        //printf("%c\n",s[k]);
        k++;
    }
    s[k]='\0';
   // printf("%s\n",s);
    
}