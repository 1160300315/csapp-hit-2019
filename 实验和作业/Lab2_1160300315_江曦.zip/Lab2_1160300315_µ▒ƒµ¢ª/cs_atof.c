//字符串转浮点数
#include <stdio.h>
#include <string.h>
#include <math.h>
float cs_atof(char* s);
int main(){
    char *s = "12.34";
    printf("%f\n",cs_atof(s));
    return 0;
}
float cs_atof(char* s){
    int len = strlen(s);
    int s_float[len];
    float final = 0;
    int flag = 0;//标志是否遇到小数点
    int frac = -1;//记录小数位数
    for(int i=0;i<len;i++){
        s_float[i] = (int)s[i]-48;
       // printf("%d\n",s_float[i]);
        if(s[i]==46){
            flag = 1;
            //printf("%d\n",flag);
        }
        else{
            if(flag){
                final+=s_float[i]*pow(10,len-i-1);
            }
            else{
                final+=s_float[i]*pow(10,len-i-2);
            }
            //printf("%f\n",final);
        }
        if(flag){
            frac++;
            //printf("%d\n",frac);
        }
    }
    final *= pow(10,-frac);
    return final;
}