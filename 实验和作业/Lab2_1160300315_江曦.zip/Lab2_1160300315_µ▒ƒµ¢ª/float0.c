//float除以0 极小浮点数后果
#include <stdio.h>
#include <limits.h>
int  main() {
    float x = 1.1;
    printf("%f\n",x/0);
    printf("%f\n",x/__FLT_MIN__);
    return 0;
}