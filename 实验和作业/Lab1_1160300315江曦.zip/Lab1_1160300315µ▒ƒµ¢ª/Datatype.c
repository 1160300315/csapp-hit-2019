#include <stdio.h>
#define VNAME(name)(#name)
typedef unsigned char *byte_pointer;

void show_bytes(byte_pointer start,size_t len){
    size_t i;
    for(i=0;i<len;i++){
        printf(" %.2x\t",start[i]);
    }
    printf("\n");
}
int main(){
    char a=1;
    char *pointer=&a;
    int array[1]={1};
    struct Struct{
        int b;
    }Struct_1;
    Struct_1.b=1;
    union Union
    {
        int c;
    }Union_1;
    Union_1.c=1;
    enum Enum{
        d=1
    }Enum_1;
    printf("%s\t%p\t%p\t",VNAME(pointer),pointer,&pointer);
    show_bytes((byte_pointer)&pointer,sizeof(pointer));
    printf("%s\t%d\t%p\t",VNAME(array),array[0],&array);
    show_bytes((byte_pointer)&array,sizeof(array));
    printf("%s\t%d\t%p\t",VNAME(Struct_1),Struct_1,&Struct_1);
    show_bytes((byte_pointer)&Struct_1,sizeof(Struct_1));
    printf("%s\t%d\t%p\t",VNAME(Union_1),Union_1,&Union_1);
    show_bytes((byte_pointer)&Union_1,sizeof(Union_1));
    printf("%s\t%d\t%p\t",VNAME(Enum_1),Enum_1,&Enum_1);
    show_bytes((byte_pointer)&Enum_1,sizeof(Enum_1));
    
    printf("%p\n",main);
    printf("%p\n",printf);
    return 0;
}