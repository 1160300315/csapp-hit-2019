#include <stdio.h>
#include <stdbool.h>

bool is_littleEndian();
int main(){
    if(is_littleEndian()){
        printf("系统是小端");
    }
    else{
        printf("系统是大端");
    }
    return 0;
}
bool is_littleEndian(){
    int x=0x01;
    if(*(char*)&x==1){
        return true;
    }
    return false;
}
