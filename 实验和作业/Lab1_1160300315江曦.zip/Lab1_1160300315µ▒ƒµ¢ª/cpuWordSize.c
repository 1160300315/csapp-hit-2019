#include <stdio.h>
int cpuWordSize();
int main(){
    printf("cpu的字长为%d个字节\n",cpuWordSize());
    return 0;
}
int cpuWordSize(){
    int w=sizeof(char*);
    return w;
}

