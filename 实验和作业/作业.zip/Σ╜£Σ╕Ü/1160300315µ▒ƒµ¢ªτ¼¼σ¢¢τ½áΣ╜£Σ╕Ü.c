/*1160300315江曦第四章作业*/
/*4.45
错误 它压入了减8的%rsp的值
movq REG,-8(%rsp)
subq %8,%rsp
*/

/*4.46
错误，它将栈指针设置为了正确的值再减去8
addq $8,%rsp
movq -8(%rsp),REG
*/

/*4.51
阶段              iaddq V,rB
取值              icode:ifun<-M1[PC]
                 rA:rB<-M1[PC+1]
                 valC<-M8[PC+2]
                 valP<-PC+10
译码             valB<-R[rB]
执行             valE<-valB+valC
访存
写回             R[rB]<-valE
更新PC           PC<-valP
*/