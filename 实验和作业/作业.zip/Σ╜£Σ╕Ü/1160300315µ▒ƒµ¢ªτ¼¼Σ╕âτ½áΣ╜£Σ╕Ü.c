/*
7.6
|Symbol    entry?    Symbol type    Module where defined    Section     |
|                                                                       |
| buf        Y         extern             m.o                .data      |
|                                                                       |
| bufp0      Y         global             swap.o             .data      |
|                                                                       |
| bufp1      Y         local              swap.o             .bss       |
|                                                                       |
| swap       Y         global             swap.o             .text      |
|                                                                       |
| temp       N         ----               ----               ----       |
|                                                                       |
| incr       Y         local              swap.o             .text      |
|                                                                       |


7.8
A.

(a) REF(main.1) -> DEF(main.1)

(b) REF(main.2) -> DEF(main.2)

B.

(a) REF(x.1) -> DEF(unkown)

(b) REF(x.2) -> DEF(unkown)

C.

(a) REF(x.1) -> DEF(ERROR)

(b) REF(x.2) -> DEF(ERROR)

7.10
A.
gcc p.o libx.a

B.
gcc p.o libx.a liby.a libx.a

C.
gcc p.o libx.a liby.a libx.a libz.a

7.12
A. 0x4004f8 – 0x4 – (0xa + 0x4004e0)，结果为：0xa

B.0x400500 – 0x4 – (0xa + 0x4004d0)，结果为：0x22
*/
