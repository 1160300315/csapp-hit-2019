/*1160300315江曦第二章作业 */
#include <stdio.h>
#include <limits.h>
int is_little_endian();
int int_shifts_are_arithmetic();
int leftmost_one(unsigned x);
int fits_bits(int x,int n);
int tsub_ok(int x,int y);
int divide_power2(int x,int k);
float fpwr2(int x);
int main(){
    printf("%d\n",is_little_endian());
    printf("%d\n",int_shifts_are_arithmetic());
    printf("%04x\n",leftmost_one(0xff00));
    printf("%04x\n",leftmost_one(0x6600));
    printf("%d\n",fits_bits(8,3));
    printf("%d\n",fits_bits(2,3));
    printf("%d\n",tsub_ok(0,INT_MIN));
    printf("%d\n",tsub_ok(0,0));
    printf("%d\n",divide_power2(-5,1));
    printf("%d\n",divide_power2(5,2));
    return 0;
}

/*
2.58 is_little_endian 小端返回1，大端返回0
 */
 int is_little_endian(){
     int a=1;
     return *((char*)&a);
 }

 /*
 2.62 对int类型使用算数右移的机器上生成1
*/
int int_shifts_are_arithmetic(){
    int x = -1;
    x = x>>1;
    if(x==-1){
        return 1;
    }
    return 0;
}
/*
2.66 生成掩码，指出x最左边的1
*/
int leftmost_one(unsigned x){
    int i=0;
    while(x!=0){
        x=x>>1;
        i++;
    }
    return 0x1<<(i-1);
}
/*
2.70 如果x的二进制能用n位表示就返回1
 */
int fits_bits(int x,int n){
    if(x>>(n-1)!=0){
        return 0;
    }
    return 1;
}
/*
2.74 如果计算x-y不溢出，函数返回1
*/
int tsub_ok(int x,int y){
    if(y==INT_MIN){
        return 0;
    }
    y=-y;
    int sum=x+y;
    int pos_over=x>0&&y>0&&sum<0;
    int neg_over=x<0&&y<0&&sum>0;
    return (!pos_over||neg_over);
}
/*
2.78 用正确的舍入方式计算x/2^k,并且遵循位级整数编码规则
c语言中除法要求向0舍入，除法本质上是右移操作
先计算x>>k，再考虑舍入
舍入的条件是x<0&&x的最后k位不为0
*/
int divide_power2(int x,int k){
    int ans=x>>k;
    int w = sizeof(int)<<3;
    ans += (x>>(w-1)) && (x&((1<<k)-1));
    return ans;
}
/*
2.82 指出下列表达式是否总为1
A.(x<y)==(-x>-y)  不是总为1 当X为INT_MIN时不成立
B.((x+y)<<4)+y-x==17*y+15*x  总为1 补码的加减乘和顺序无关 但如果是右移 可能会不同
C.~x+~y+1==~(x+y) 总为1 ～x+~y+1=~x+1+~y+1-1=-x-y-1=-(x+y)-1=~(x+y)+1-1=~(x+y)
D.(ux-uy)==-(unsigned)(y-x) 总为1 位级表示相同
E.((x>>2)<<2)<=x 总为1 最后两个bit清零，所以x不变或者变小
*/
/*2.86  
最小的正非规格化数   2^(-63)*2^(-2^14+2) 3.6452e-4951
最小的正规格化数     2^(-2^14+2) 3.3621e-4932
最大的规格化数      (2-2^63)*2^(2^14-1)  1.1897e+4932
*/
/*2.90 计算2^x的浮点表示
*/
/* 
float fpwr2(int x){
    unsigned exp,frac;
    unsigned u;
    if(x<-149){
        exp=0;
        frac=0;
    }else if(x<-126){
        exp=0;
        frac=1<<(x+149);
    }else if(x<128){
        exp=x+127;
        frac=0;
    }else{
        exp=255;
        frac=0;
    }
    u=exp<<23|frac;
    return u2f(u);
}
*/
/*2.94 计算2.0*f 如果f是NaN，返回f
*/
/* 
float_bits float_twice(float_bits f){
    unsigned sign=f>>31;
    unsigned exp=(f>>23)&0xFF;
    unsigned frac=f&0x7FFFFF;
    if(exp==0){
        return sign<<31|frac<<1;
    }
    else if(exp<254){
        return sign<<31|(exp+1)<<23|frac};
    }
    else if(exp==254){
        return sign<<31|0xFF<<23;
    }
    else return f;
}
*/