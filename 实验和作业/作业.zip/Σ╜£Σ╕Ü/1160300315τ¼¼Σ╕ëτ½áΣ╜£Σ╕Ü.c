/*1160300315江曦第三章课后作业*/
#include <stdio.h>
long decode2(long x, long y, long z);
long loop(long x, int n);
long switch3(long *p1,long *p2,mode_t action);

int main(int argc, char const *argv[])
{
    
    return 0;
}
/*3.58
*/
long decode2(long x, long y, long z){
    y=y-z;
    x=x*y;
    x=x<<63;
    x=x>>63;
    return y^x;
}
/*3.60
A %rdi %esi %rax %rdx
B 0 1
C mask!=0
D test %rdx,%rdx
  jne  .L3
  mask&mask!=0跳转到.L3 即mask!=0跳转到.L3
E movq %rdi,%r8 //%r8=x
  andq %rdx,%r8 //%r8=x&mask
F如下： 
*/
long loop(long x, int n){
    long result=0;
    long mask;
    for(mask=1;mask!=0;mask=mask<<(n%256)){
        result |= x&mask;
    }
    return result;
}
/*3.62
*/
typedef enum{MODE_A,MODE_B,MODE_C,MODE_D,MODE_E} mode_t;
long switch3(long *p1,long *p2,mode_t action){
    long result=0;
    switch (action)
    {
    
    case MODE_A: 
        result = *p2 ;
        *p2=*p1; 
        break;
    case MODE_B: 
        result = *p1 + *p2; 
        *p1 = result; 
        break;
    case MODE_C: 
        *p1 = 59; 
        result = *p2; 
        break;
    case MODE_D: 
        *p1 = *p2; 
        result=27; 
        break;
    case MODE_E: 
        result = 27; 
        break;
    default: 
        result = 12; 
        break;
    }
}
/*3.64
A.  &A[i][j][k]=xA+L(i*ST+j*T+k)
B.  store_ele:
    leaq  (%rsi, %rsi, 2), %rax  # %rax = 3 * j
    leaq  (%rsi, %rax, 4), %rax  # %rax = j + 4(3j) = 13 * j
    leaq  %rdi, %rsi             # %rsi = i
    salq  $6, %rsi               # %rsi * = 64
    addq  %rsi, %rdi             # %rdi = 65 * i
    addq  %rax, %rdi             # %rdi = 65 * i + 13 * j
    addq  %rdi, %rdx             # %rdx = 65 * i + 13 * j + k
    movq  A(, %rdx, 8), %rax     # %rax = A + 8 * (65 * i + 13 * j + k)
    movq  %rax, (%rcx)           # *dest = A[65 * i + 13 * j + k]
    movl  $3640, %eax            # sizeof(A) = 3640
    ret
    R=7
    S=5
    T=13
*/
/*3.66
NR（n）=3n NC（n）=4n+1
由15行可知rdi中存的为NR（n），再由3、4行可知rdi=3n,故NR(n)=3n
由8、12、14行可知，&A[i][j]=A+8(i*(4n+1)+j),故NC(n)=4n+1
*/
/*3.68
A=9 B=5
从汇编movslq 8(%rsi), %rax中，可以看出结构体str2中int t是从第2个八字节开始
从而5<=B<=8
从汇编addq 32(%rsi), %rax中，可以看出结构体str2中long u是从第5个八字节开始
从而7<=A<=10
从汇编movq %rax, 184(%rdi)中，184既可能是最大情况，也可能是8字节补齐情况
所以184-8<A*B*4<=18
所以得到A=9 B=5
*/
/*3.70
A.  0
    8
    0
    8
B.  16
C.
*/
union ele
{
    struct{
        long *p;
        long y;
    }e1;
    struct{
        long x;
        union ele *next;
    }e2;
};
void proc(union ele *up){
    up->e2.x=*(*(up->e2.next)->e1.p)-*(up->e2.next)->e1.y;
}
/*3.72
A.
s2​=s1​−((8∗n+30)&0xfffffff0)
当n为偶数时，s2​=s1​−(8∗n+16)
当n为奇数时，s2​=s1​−(8∗n+24)
B.
p=(s2​+15)&0xfffffff0
C. 
要使e1的值最小，则需使e1+e2最小同时e2最大。当n为偶数时，e1+e2=16最小；当s1%16=1时，e2=15最大。
即：n为偶数，s1%16=1时e1最小。
要使e1的值最大，则需使e1+e2最大同时e2最小。当n为奇数时，e1+e2=24最大；当s1%16=0时，e2=0最小。
即：n为奇数，s1%16=0时e1最大。
D. 
s2保证空间足够容纳数组p，且是最小的16的倍数。
P以16的倍数对齐。
*/
