/*
6.26
2048 256 
4 4
25 6
32 5

6.30
A. C=S*E*B=8*4*4=128
B.12~5:CT
  5~2:CI
  1~0:CO

6.34
dst
m m m m
m m m m
m m m m
src
m m h m
m h m h
m m h m
m h m h

6.38
A.16*16*16*4=1024
B.1023/8=128
C.1/8

6.42
1/4

*/
